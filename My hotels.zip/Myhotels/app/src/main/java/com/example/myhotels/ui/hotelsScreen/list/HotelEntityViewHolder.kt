package com.example.myhotels.ui.hotelsScreen.list

import androidx.recyclerview.widget.RecyclerView
import com.example.myhotels.databinding.HotelItemBinding

class HotelEntityViewHolder(
    val binding: HotelItemBinding
) : RecyclerView.ViewHolder(binding.root)